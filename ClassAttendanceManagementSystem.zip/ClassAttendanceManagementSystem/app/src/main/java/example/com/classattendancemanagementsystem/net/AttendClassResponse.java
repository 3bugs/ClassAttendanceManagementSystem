package example.com.classattendancemanagementsystem.net;

import com.google.gson.annotations.SerializedName;

public class AttendClassResponse extends BaseResponse {

    @SerializedName("course_code")
    public String courseCode;
    @SerializedName("course_name")
    public String courseName;
    @SerializedName("attend_date")
    public String attendDate;

}
