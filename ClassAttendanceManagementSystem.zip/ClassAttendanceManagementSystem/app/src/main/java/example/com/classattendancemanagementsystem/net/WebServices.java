package example.com.classattendancemanagementsystem.net;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface WebServices {

    @FormUrlEncoded
    @POST("ldap.php")
    Call<LoginResponse> login(
            @Field("username") String username,
            @Field("password") String password
    );

    @FormUrlEncoded
    @POST("api.php/insert_student")
    Call<LoginResponse> addUser(
            @Field("username") String username,
            @Field("display_name") String displayName
    );

    @FormUrlEncoded
    @POST("api.php/insert_class_attendance")
    Call<AttendClassResponse> attendClass(
            @Field("course_code") String courseCode,
            @Field("student_id") int userId
    );

    /*@FormUrlEncoded
    @POST("user.php/register")
    Call<RegisterResponse> register(
            @Field("username") String username,
            @Field("password") String password,
            @Field("name") String name,
            @Field("lastname") String lastname,
            @Field("address") String address,
            @Field("phone") String phone,
            @Field("gender") int gender,
            @Field("age") int age,
            @Field("email") String email,
            @Field("user_type") int userType
    );

    @FormUrlEncoded
    @POST("api.php/elderly_select_job")
    Call<GetJobResponse> getJobElderly(
            @Field("elderly_id") int elderlyId
    );

    @FormUrlEncoded
    @POST("api.php/elderly_select_job_apply")
    Call<GetJobResponse> getApplyJobElderly(
            @Field("elderly_id") int elderlyId
    );

    @FormUrlEncoded
    @POST("api.php/apply_job")
    Call<BaseResponse> applyJob(
            @Field("job_id") int jobId,
            @Field("elderly_id") int elderlyId
    );

    @FormUrlEncoded
    @POST("api.php/employer_select_job")
    Call<GetJobResponse> getJobEmployer(
            @Field("employer_id") int employerId
    );

    @FormUrlEncoded
    @POST("api.php/post_job")
    Call<BaseResponse> postJob(
            @Field("title") String jobTitle,
            @Field("details") String jobDetails,
            @Field("image") String jobImage,
            @Field("type") int jobType,
            @Field("employer_id") int employerId
    );*/
}
