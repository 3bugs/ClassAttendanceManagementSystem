<?php

require_once '../db_config.php';
$db = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
if ($db->connect_errno) {
    header('Content-type: text/html; charset=utf-8');
    echo 'เกิดข้อผิดพลาดในการเชื่อมต่อฐานข้อมูล';
    exit();
}

$db->set_charset("utf8");

?>
    <!DOCTYPE html>
    <html>
    <head>
        <?php require_once 'header.php'; ?>

        <script>
            $(document).ready(function () {
                /*$('#submit_button').on("click", function(event) {
                    var courseSelectValue = $('#course_select').val();
                    if (courseSelectValue !== null) {

                    } else {
                        alert('เลือกวิชา');
                    }
                });*/

                <?php
                if (isset($_POST['submit_button'])) {
                $courseCode = $_POST['course_select'];
                ?>
                var intervalId = setInterval(function () {
                        $.get("student_list.php?course_code=<?php echo $courseCode; ?>", function (data) {
                            var studentListDiv = $('#student_list_div');
                            studentListDiv.empty();
                            studentListDiv.append(data);
                        });
                    }, 12000
                );
                <?php
                }
                ?>
            });

            function validateForm() {
                var courseSelectValue = $('#course_select').val();
                if (courseSelectValue !== null) {
                    return true;
                } else {
                    alert('เลือกวิชา');
                    return false;
                }
            }

        </script>
    </head>

    <body>
    <div style="margin: 50px 200px 50px 200px; text-align: center; ">
        <h2>Class Attendance Management System</h2>
        <br><br>
        <form method="post" onsubmit="return validateForm()">
            <div class="form-group">

                <select class="form-control" id="course_select" name="course_select">
                    <option value="-1" disabled selected> -- เลือกวิชาเรียน --</option>
                    <?php
                    $sql = "SELECT * FROM course";
                    $result = $db->query($sql);
                    if ($result) {
                        while ($row = $result->fetch_assoc()) {
                            $courseId = $row['id'];
                            $courseCode = $row['code'];
                            $courseName = $row['name'];
                            ?>
                            <option value="<?php echo $courseCode; ?>"><?php echo "$courseCode - $courseName"; ?></option>
                            <?php
                        }
                        $result->close();
                    }
                    ?>
                </select>
            </div>
            <input class="btn btn-primary" type="submit" id="submit_button" name="submit_button" value="เลือก" / >
        </form>

        <?php
        if (isset($_POST['submit_button'])) {
            ?>
            <br>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <tr>
                        <th>รหัสวิชา</th>
                        <th>ชื่อวิชา</th>
                    </tr>
                    <?php
                    $courseCode = $_POST['course_select'];
                    $sql = "SELECT * FROM course WHERE code = '$courseCode'";
                    $result = $db->query($sql);
                    if ($result) {
                        $row = $result->fetch_assoc();
                        ?>
                        <tr>
                            <td><?php echo $row['code'] ?></td>
                            <td><?php echo $row['name'] ?></td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <table>
                                    <tr>
                                        <td>
                                            <img src="qr.php?code=<?php echo $row['code']; ?>" width="250px"
                                                 height="250px">
                                        </td>
                                        <td valign="top" align="center">
                                            <h3><u>รายชื่อนักศึกษาเข้าเรียน</u></h3>
                                            <div id="student_list_div"></div>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </table>
            </div>
            <?php
        }
        ?>
    </div>
    </body>
    </html>
<?php
$db->close();
?>