<?php

define('DB_USER', 'cams_admin');
define('DB_PASSWORD', 'abc123');
define('DB_SERVER', 'localhost');
define('DB_DATABASE', 'cams');

?>
